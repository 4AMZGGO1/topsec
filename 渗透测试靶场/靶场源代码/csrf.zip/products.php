<?php
// products.php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $product_id = $_POST['product_id'];

    // 检查余额
    $stmt = $pdo->prepare('SELECT balance FROM users WHERE id = ?');
    $stmt->execute([$user_id]);
    $balance = $stmt->fetchColumn();

    // 获取商品价格
    $stmt = $pdo->prepare('SELECT price FROM products WHERE id = ?');
    $stmt->execute([$product_id]);
    $price = $stmt->fetchColumn();

    if ($balance >= $price) {
        // 扣除余额
        $new_balance = $balance - $price;
        $stmt = $pdo->prepare('UPDATE users SET balance = ? WHERE id = ?');
        $stmt->execute([$new_balance, $user_id]);

        echo "购买成功！";
    } else {
        echo "余额不足！";
    }
}

$stmt = $pdo->query('SELECT * FROM products');
$products = $stmt->fetchAll();
?>

<h2>商品列表</h2>

<?php foreach ($products as $product): ?>
    <div>
        <p><?= htmlspecialchars($product['name']) ?> - <?= htmlspecialchars($product['price']) ?>元</p>
        <form method="POST">
            <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
            <button type="submit">购买</button>
        </form>
    </div>
<?php endforeach; ?>
