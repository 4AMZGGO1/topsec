<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['avatar'])) {
    $avatar = $_FILES['avatar']['name'];
    $target = 'uploads/' . basename($avatar);

    if (move_uploaded_file($_FILES['avatar']['tmp_name'], $target)) {
        $stmt = $pdo->prepare('UPDATE users SET avatar = ? WHERE id = ?');
        $stmt->execute([$avatar, $_SESSION['user_id']]);
        header('Location: profile.php');
    } else {
        echo '头像上传失败';
    }
}
?>
