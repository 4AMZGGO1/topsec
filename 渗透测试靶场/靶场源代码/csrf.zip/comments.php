<?php
// comments.php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comment'])) {
    $comment = $_POST['comment'];

    $stmt = $pdo->prepare('INSERT INTO products (comment) VALUES (?)');
    $stmt->execute([$comment]);

    echo "评论成功！";
}

$stmt = $pdo->query('SELECT comment FROM products');
$comments = $stmt->fetchAll();
?>

<h2>商品评论</h2>

<form method="POST">
    <textarea name="comment" placeholder="写下您的评论"></textarea><br>
    <button type="submit">发表评论</button>
</form>

<?php foreach ($comments as $comment): ?>
    <div>
        <?= $comment['comment'] ?> <!-- 存在XSS漏洞 -->
    </div>
<?php endforeach; ?>
