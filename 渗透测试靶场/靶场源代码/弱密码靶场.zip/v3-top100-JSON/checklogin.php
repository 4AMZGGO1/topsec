<?php 
ini_set("allow_url_include","on");
header("Content-Type: application/json");

$json_data = file_get_contents("php://input");
$data = json_decode($json_data,true);

if ($data['username'] == 'admin' and $data['password'] == 'zxcvbnm') {
    $response = array("status" => "success","message" => "x1ongsec{7b76c384c2-8bf94c021a-44651dca3d}");
}else if ($data['username'] == '' or $data['password'] == '') {
    $response = array("status" => "error","message" => "请输入用户名和密码");
}else if ($data == null) {
    $response = array("status" => "error","message" => "JSON syntax error");
}else {
    $response = array("status" => "error","message" => "用户名或或密码错误");
}
echo json_encode($response);
?>

