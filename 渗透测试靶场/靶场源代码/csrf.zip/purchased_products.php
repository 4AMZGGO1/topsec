<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// 获取用户购买的商品
$stmt = $pdo->prepare('
    SELECT p.name, p.price, pu.purchase_date 
    FROM purchases pu 
    JOIN products p ON pu.product_id = p.id 
    WHERE pu.user_id = ?
');
$stmt->execute([$_SESSION['user_id']]);
$purchased_products = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>已购商品</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php include 'nav.php'; ?> <!-- 导航栏 -->
<div class="container">
    <h2>已购商品</h2>

    <?php if (count($purchased_products) === 0): ?>
        <p>您还没有购买任何商品。</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>商品名称</th>
                    <th>价格</th>
                    <th>购买时间</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($purchased_products as $product): ?>
                    <tr>
                        <td><?= htmlspecialchars($product['name']) ?></td>
                        <td><?= htmlspecialchars($product['price']) ?> 元</td>
                        <td><?= htmlspecialchars($product['purchase_date']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
</body>
</html>
