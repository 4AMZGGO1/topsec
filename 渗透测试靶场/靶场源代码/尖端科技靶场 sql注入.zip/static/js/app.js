﻿document.addEventListener('DOMContentLoaded', function() {
    loadAllProducts();

    const searchButton = document.getElementById('searchButton');
    searchButton.addEventListener('click', performAdvancedSearch);
});

const INTERNAL_API_PATH = '/api/developer_utils/sorted_query';

function executeInternalQuery(options) {
    console.log("Internal query tool is not implemented on the frontend.");
}

function loadAllProducts() {
    fetch('/api/get_all_products')
        .then(response => response.json())
        .then(data => renderProducts(data))
        .catch(error => console.error('Failed to fetch all products:', error));
}

function performAdvancedSearch() {
    const query = document.getElementById('searchQuery').value;
    const sortBy = document.getElementById('sortBy').value;

    const searchOptions = {
        query: query,
        sortBy: sortBy,
        order: 'asc'
    };

    fetch('/api/public_search', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(searchOptions)
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert('Error: ' + data.error);
            return;
        }
        renderProducts(data);
    })
    .catch(error => console.error('Advanced search failed:', error));
}

function renderProducts(products) {
    const productList = document.getElementById('product-list');
    productList.innerHTML = '';
    if (products.length === 0) {
        productList.innerHTML = '<p class="text-center text-muted">没有找到符合条件的产品。</p>';
        return;
    }
    products.forEach(product => {
        const card = `
            <div class="col-md-6 col-lg-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">${product.name}</h5>
                        <p class="card-text text-muted">${product.description}</p>
                    </div>
                    <div class="card-footer bg-transparent border-top-0">
                        <p class="card-text fs-5 fw-bold text-end">¥${product.price}</p>
                    </div>
                </div>
            </div>
        `;
        productList.innerHTML += card;
    });
}