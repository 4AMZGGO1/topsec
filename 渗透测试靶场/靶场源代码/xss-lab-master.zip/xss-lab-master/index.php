<!DOCTYPE html><!--STATUS OK--><html>
<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8">
<title>欢迎来到XSS挑战</title>
</head>
<body>
<h1 align=center>欢迎来到XSS挑战</h1>
<a href=level1.php?name=test><center><img src=index.png></center></a>
<h2 align=center>点击图片开始你的XSS之旅吧！</h2>
</body>
</html>


