<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// 处理修改密码请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_password'])) {
    $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT); // 哈希处理新密码

    // 更新用户密码
    $stmt = $pdo->prepare('UPDATE users SET password = ? WHERE id = ?');
    $stmt->execute([$new_password, $_SESSION['user_id']]);

    $message = "密码修改成功！";
}

// 处理头像路径请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['avatar_path'])) {
    $avatar_path = $_POST['avatar_path'];

    // 更新用户头像路径
    $stmt = $pdo->prepare('UPDATE users SET avatar = ? WHERE id = ?');
    $stmt->execute([$avatar_path, $_SESSION['user_id']]);

    $message_avatar = "头像修改成功！";
}

// 处理上传头像请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['avatar'])) {
    $avatar = $_FILES['avatar'];

    // 简单的文件上传验证
    if ($avatar['error'] === UPLOAD_ERR_OK) {
        $target_directory = 'uploads/';
        $target_file = $target_directory . basename($avatar['name']);
        move_uploaded_file($avatar['tmp_name'], $target_file);

        // 更新用户头像路径
        $stmt = $pdo->prepare('UPDATE users SET avatar = ? WHERE id = ?');
        $stmt->execute([basename($avatar['name']), $_SESSION['user_id']]);

        $message_avatar = "头像上传成功！";
    } else {
        $message_avatar = "头像上传失败！";
    }
}

// 获取用户信息
$stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>个人信息</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php include 'nav.php'; ?> <!-- 导航栏 -->
<div class="container">
    <h2>个人信息</h2>
    
    <p>用户名: <?= htmlspecialchars($user['username']) ?></p>
    <p>余额: <?= htmlspecialchars($user['balance']) ?> 元</p>

    <h3>修改密码</h3>
    <?php if (isset($message)): ?>
        <p><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>
    
    <form method="POST" action="profile.php">
        <input type="password" name="new_password" placeholder="新密码" required><br>
        <button type="submit">修改密码</button>
    </form>

    <h3>设置头像地址或上传头像</h3>
    <?php if (isset($message_avatar)): ?>
        <p><?= htmlspecialchars($message_avatar) ?></p>
    <?php endif; ?>

    <form method="POST" action="profile.php" enctype="multipart/form-data">
        <input type="file" name="avatar" accept="image/*" required>
        <button type="submit">上传头像</button>
    </form>

    <form method="POST" action="profile.php">
        <input type="text" name="avatar_path" placeholder="输入头像地址" required>
        <button type="submit">保存头像地址</button>
    </form>
</div>
</body>
</html>
