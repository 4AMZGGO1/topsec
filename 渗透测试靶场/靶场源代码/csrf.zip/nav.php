<nav>
    <a href="register.php">注册</a>
    <a href="login.php">登录</a>
    <a href="profile.php">个人信息</a>
    <a href="product_list.php">商品列表</a>
    <a href="product_comments.php">评论</a>
    <a href="purchased_products.php">已购商品</a> <!-- 新增链接 -->
    <a href="logout.php">退出</a>
</nav>
