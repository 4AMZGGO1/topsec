#!/bin/sh

java "-Ddubbo.registry.address=${DUBBO_REGISTRY}" -jar /dubbo-sample-1.0-SNAPSHOT.jar
