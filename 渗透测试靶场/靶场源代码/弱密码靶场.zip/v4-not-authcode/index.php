<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>X1ongSec | 后台管理系统</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <script src="./js/jquery-3.6.4.min.js"></script>
    <script>
                function refreshCaptcha() {
            $.ajax({
                type: 'GET',
                url: 'captcha.php',
                success: function(data) {
                    $('#captchaImage').attr('src', 'captcha.php');
                }
            });
        }
    </script>
    <style media="screen">
        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box
        }

        body {
            font-family: sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            background: #0c0116
        }

        .form {
            position: relative;
            padding: 60px 15px;
            width: 270px;
            height: 390px;
            background: #0c0116;
            overflow: hidden;
            box-shadow: 0 0 10px 0 #747772;
            border-radius: 5px
        }

        .form-inner {
            position: absolute;
            height: 98%;
            width: 98%;
            top: 50%;
            left: 50%;
            background: #0c0116;
            transform: translate(-50%, -50%)
        }

        .content {
            height: 100%;
            width: 100%;
            padding: 25px
        }

        .form-inner h2 {
            font-size: 25px;
            color: #d7a3d7;
            text-align: center;
            padding-top: 35px
        }

        .input {
            display: block;
            padding: 12px 15px;
            width: 100%;
            left: 50%;
            border-radius: 10px;
            margin-top: 20px;
            border: 1.5px solid #6d5779;
            outline: 0;
            background: #19052c;
            color: white
        }

        .btn {
            cursor: pointer;
            color: white;
            margin-top: 20px;
            width: 100%;
            padding: 12px;
            outline: 0;
            background: #800080;
            border: 0;
            font-size: 18px;
            border-radius: 10px;
            transition: .4s
        }

        .btn:hover {
            background: #c907c9
        }

        .form span {
            position: absolute;
            height: 50%;
            width: 50%
        }

        .form span:nth-child(1) {
            background: #ffda05;
            top: 0;
            left: -48%;
            animation: 5s span1 infinite linear;
            animation-delay: 1s
        }

        .form span:nth-child(2) {
            background: #00a800;
            bottom: 0;
            right: -48%;
            animation: 5s span2 infinite linear
        }

        .form span:nth-child(3) {
            background: #800080;
            right: -48%;
            top: 0;
            animation: 5s span3 infinite linear
        }

        .form span:nth-child(4) {
            background: #f00;
            bottom: 0;
            right: -48%;
            animation: 5s span4 infinite linear;
            animation-delay: 1s
        }

        @keyframes span1 {
            0% {
                top: -48%;
                left: -48%
            }

            25% {
                top: -48%;
                left: 98%
            }

            50% {
                top: 98%;
                left: 98%
            }

            75% {
                top: 98%;
                left: -48%
            }

            100% {
                top: -48%;
                left: -48%
            }
        }

        @keyframes span2 {
            0% {
                bottom: -48%;
                right: -48%
            }

            25% {
                bottom: -48%;
                right: 98%
            }

            50% {
                bottom: 98%;
                right: 98%
            }

            75% {
                bottom: 98%;
                right: -48%
            }

            100% {
                bottom: -48%;
                right: -48%
            }
        }

        @keyframes span3 {
            0% {
                top: -48%;
                left: -48%
            }

            25% {
                top: -48%;
                left: 98%
            }

            50% {
                top: 98%;
                left: 98%
            }

            75% {
                top: 98%;
                left: -48%
            }

            100% {
                top: -48%;
                left: -48%
            }
        }

        @keyframes span4 {
            0% {
                bottom: -48%;
                right: -48%
            }

            25% {
                bottom: -48%;
                right: 98%
            }

            50% {
                bottom: 98%;
                right: 98%
            }

            75% {
                bottom: 98%;
                right: -48%
            }

            100% {
                bottom: -48%;
                right: -48%
            }
        }
        .fl {
            float: left;
        }

        .content::after{
            content: "";
            clear: both;
        }
    </style>
</head>

<body>
    <form method="post" class="form"><span></span><span></span><span></span><span></span>
        <div class="form-inner">
            <h2>后台管理系统</h2>
            <div class="content">
                <input class="input" type="text" placeholder="用户名: admin" name="username" />
                <input class="input" type="password" placeholder="密码: 弱口令" name="password" />
                <input type="text" class="input fl" placeholder="输入验证码" style="width: 100px;" maxlength="5" name="code">
                <img src="captcha.php" alt="" class="fl" style="display: block;margin-top:20px;margin-left:14px;cursor:pointer;" onclick="refreshCaptcha()" id="captchaImage">
                <button type="submit" value="登陆" name="submit" class="btn">登录</button></div>
        </div>
    </form>
</body>

</html>
<?php
if (isset($_POST['submit']) and isset($_POST['username']) and isset($_POST['username']) and isset($_POST['code'])){
    if (strtolower($_POST['code']) == strtolower($_SESSION['captcha_code'])) {
        if ($_POST['username'] === 'admin' and $_POST['password'] === 'qwe123..') {
            echo "<script>alert('x1ongsec{c3aab41633-a01e2b32dc-65af4558cf}');</script>";
        } else {
            echo "<script>alert('用户名或密码错误！');</script>";
        }
    } else {
        echo "<script>alert('验证码错误！');</script>";
    }
}
?>
