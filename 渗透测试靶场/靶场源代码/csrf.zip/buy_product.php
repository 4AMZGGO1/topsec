<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = $_POST['product_id'];

    // 获取商品信息
    $stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
    $stmt->execute([$product_id]);
    $product = $stmt->fetch();

    // 获取用户信息
    $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    if ($user['balance'] >= $product['price']) {
        // 扣除用户余额
        $new_balance = $user['balance'] - $product['price'];
        $stmt = $pdo->prepare('UPDATE users SET balance = ? WHERE id = ?');
        $stmt->execute([$new_balance, $_SESSION['user_id']]);
        
        // 插入购买记录
        $stmt = $pdo->prepare('INSERT INTO purchases (user_id, product_id) VALUES (?, ?)');
        $stmt->execute([$_SESSION['user_id'], $product_id]);

        echo '购买成功';
    } else {
        echo '余额不足';
    }
}
?>
