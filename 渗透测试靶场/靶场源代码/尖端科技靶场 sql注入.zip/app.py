﻿import pymysql
from flask import Flask, jsonify, render_template, request, json

app = Flask(__name__)


app.json.ensure_ascii = False

DB_CONFIG = {
    'host': 'localhost',
    'user': 'webapp_user',
    'password': 'StrongPassword123!',
    'db': 'webapp_db',
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

def get_db_connection():
    try:
        return pymysql.connect(**DB_CONFIG)
    except pymysql.MySQLError as e:
        print(f"数据库连接失败: {e}")
        return None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/get_all_products', methods=['GET'])
def get_all_products():
    conn = get_db_connection()
    if not conn: return jsonify({"error": "数据库连接失败"}), 500
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT id, name, description, price FROM products ORDER BY id")
            return jsonify(cursor.fetchall())
    finally:
        if conn: conn.close()

@app.route('/api/public_search', methods=['POST'])
def public_search():
    data = request.get_json()
    query = data.get('query', '')
    sort_by = data.get('sortBy', 'name').lower()
    order = data.get('order', 'asc').lower()

    allowed_sort_columns = ['name', 'price']
    if sort_by not in allowed_sort_columns:
        return jsonify({"error": "无效的排序列"}), 400
    if order not in ['asc', 'desc']:
        return jsonify({"error": "无效的排序顺序"}), 400

    conn = get_db_connection()
    if not conn: return jsonify({"error": "数据库连接失败"}), 500
    
    try:
        with conn.cursor() as cursor:
            sql = f"SELECT id, name, description, price FROM products WHERE name LIKE %s OR description LIKE %s ORDER BY {sort_by} {order}"
            search_term = f"%{query}%"
            cursor.execute(sql, (search_term, search_term))
            return jsonify(cursor.fetchall())
    except pymysql.MySQLError as e:
        return jsonify({"error": f"查询失败: {e}"}), 500
    finally:
        if conn: conn.close()

@app.route('/api/developer_utils/sorted_query', methods=['POST'])
def developer_sorted_query():
    try:
        data = request.get_json()
        if not data: return jsonify({"error": "请求体不能为空且必须是JSON格式"}), 400
            
        sort_by_column = data.get('sortBy', 'id')
        sort_order = data.get('order', 'asc')
        query_term = data.get('query', '')

        if sort_order.lower() not in ['asc', 'desc']:
            sort_order = 'asc'

        conn = get_db_connection()
        if not conn: return jsonify({"error": "数据库连接失败"}), 500
        
        try:
            with conn.cursor() as cursor:
                search_term = f"%{query_term}%"
                sql_query = f"SELECT id, name, description, price FROM products WHERE name LIKE %s OR description LIKE %s ORDER BY {sort_by_column} {sort_order}"
                
                print(f"Executing vulnerable query: {sql_query}")
                cursor.execute(sql_query, (search_term, search_term))
                return jsonify(cursor.fetchall())
        except pymysql.MySQLError:
            return jsonify({"error": "查询时发生内部错误"}), 500
        finally:
            if conn: conn.close()
    except Exception:
        return jsonify({"error": "服务器发生未知错误"}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
