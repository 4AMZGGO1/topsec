<?php
// 启动会话以存储验证码
session_start();

// 生成四位数字+字母的验证码
$code = generateRandomCode(5);

// 存储验证码到会话
$_SESSION['captcha_code'] = $code;

// 创建图像
$image = imagecreatetruecolor(100, 42.5);

// 设置背景颜色
$bgColor = imagecolorallocate($image,25,4,44);
imagefill($image, 0, 0, $bgColor);

// 设置文本颜色
$textColor = imagecolorallocate($image, 235, 235, 235);

// 设置字体路径（使用默认字体）
$font = 'font/TAHOMA.ttf';

// 在图像上写入验证码
imagettftext($image, 18, 1, 10, 30, $textColor, $font, $code);

// 设置响应头为图像格式
header('Content-Type: image/png');

// 输出图像
imagepng($image);

// 销毁图像资源
imagedestroy($image);

// 生成随机的四维数字+字母验证码
function generateRandomCode($length = 4) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $code = '';
    for ($i = 0; $i < $length; $i++) {
        $code .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $code;
}
?>