# xss-lab

20 XSS challenge questions, from easy to difficult, worth trying for novice players. Additionally, I have uploaded a write-up for reference. If there are any errors or better suggestions, feel free to reach out to me. :)

20道XSS通关题目，由浅入深，值得新手玩家们一试，另外本人上传了一份wiriteup作为参考，如果有错误或者更好的建议，欢迎call我:)
