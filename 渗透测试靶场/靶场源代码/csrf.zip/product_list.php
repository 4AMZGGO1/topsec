<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$stmt = $pdo->query('SELECT * FROM products');
$products = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>商品列表</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php include 'nav.php'; ?> <!-- 导航栏 -->
<div class="container">
    <h2>商品列表</h2>

    <?php foreach ($products as $product): ?>
        <div class="product">
            <p>商品名: <?= htmlspecialchars($product['name']) ?> - <?= htmlspecialchars($product['price']) ?>元</p>
            <form method="POST" action="buy_product.php">
                <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                <button type="submit">购买</button>
            </form>
        </div>
    <?php endforeach; ?>
</div>
</body>
</html>
