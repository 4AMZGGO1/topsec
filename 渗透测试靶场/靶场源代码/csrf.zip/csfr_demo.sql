﻿# Host: localhost  (Version: 5.5.53)
# Date: 2025-02-19 15:20:37
# Generator: MySQL-Front 5.3  (Build 4.234)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "comments"
#

DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

#
# Data for table "comments"
#

/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (25,1,'111'),(26,3,'111'),(27,4,'AA');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;

#
# Structure for table "products"
#

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `price` decimal(10,2) DEFAULT '10.00',
  `comment` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

#
# Data for table "products"
#

/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'商品A',10.00,''),(2,'商品B',15.00,''),(3,'商品C',20.00,''),(4,'商品D',30.00,'');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

#
# Structure for table "purchases"
#

DROP TABLE IF EXISTS `purchases`;
CREATE TABLE `purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `purchase_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

#
# Data for table "purchases"
#

/*!40000 ALTER TABLE `purchases` DISABLE KEYS */;
INSERT INTO `purchases` VALUES (1,1,1,NULL),(2,1,1,NULL),(3,1,1,NULL),(4,3,1,NULL);
/*!40000 ALTER TABLE `purchases` ENABLE KEYS */;

#
# Structure for table "users"
#

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `balance` decimal(10,2) DEFAULT '100.00',
  `avatar` varchar(255) DEFAULT 'default.png',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

#
# Data for table "users"
#

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'1','$2y$10$qjikNiFX1yIiuPsxupAdbODJ16Z0Xg6Xu8bNeHM5kedd2yoq1YeL6',60.00,'1720750773597.jpg'),(2,'root','$2y$10$tW7vh77c.8leastJQmfg5eSnxj.7lU7X04O/DcQcMX8WutQdryRrq',100.00,'default.png'),(3,'test','$2y$10$s3CYnWyAXjqZE7JCiM0X2.vP8X4wxNzvBNXt6DVUFw257S09poNY6',90.00,'../logout.php'),(4,'2','$2y$10$qFe2OlxmMmijlRMtvkhKW.OUHLztZFxbktiG80BBf.US/1adk8TvK',100.00,'1720750773597.jpg'),(5,'qiaoliwa','$2y$10$OWq9KgPbWEPzTgoahhupju0jJumYNWgwYMf9aWoG6PbVub0edb5Eq',100.00,'default.png');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
