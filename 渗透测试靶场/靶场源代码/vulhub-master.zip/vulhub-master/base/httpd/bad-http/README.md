# [deprecated] 绝版apache+php

允许HTTP HOST里插入恶意字符的Apache，已绝版，用该Dockerfile生成的新的Apache没有该特效，该Dockerfile只是演示当初这个镜像是怎么生成的。

镜像地址：vulhub/httpd:bad-http
