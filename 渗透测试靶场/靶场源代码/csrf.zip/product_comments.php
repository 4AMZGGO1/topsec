<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// 处理提交评论
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $comment = $_POST['comment'];
    // 直接插入未经处理的评论内容，故意保留XSS漏洞
    $stmt = $pdo->prepare('INSERT INTO comments (user_id, comment) VALUES (?, ?)');
    $stmt->execute([$_SESSION['user_id'], $comment]);

    // 提交成功后，使用PRG模式进行重定向，避免重复提交
    header('Location: product_comments.php');
    exit; // 确保重定向后停止后续代码执行
}

// 获取所有评论及其用户的头像和用户名
$stmt = $pdo->query('
    SELECT c.comment, u.username, u.avatar 
    FROM comments c 
    JOIN users u ON c.user_id = u.id
');
$comments = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>商品评论</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php include 'nav.php'; ?> <!-- 导航栏 -->
<div class="container">
    <h2>评论</h2>

    <form method="POST" action="product_comments.php">
        <textarea name="comment" placeholder="发表评论" required></textarea><br>
        <button type="submit">提交评论</button>
    </form>

    <h3>评论列表</h3>
    <?php foreach ($comments as $comment): ?>
        <div class="comment">
            <!-- 显示用户头像 -->
            <img src="uploads/<?= htmlspecialchars($comment['avatar']) ?>" alt="用户头像" width="50" height="50" style="border-radius:50%;">
            <p><strong><?= htmlspecialchars($comment['username']) ?>:</strong></p>
            <!-- 故意保留XSS漏洞，直接输出未经处理的评论内容 -->
            <p><?= $comment['comment'] ?></p>
        </div>
    <?php endforeach; ?>
</div>
</body>
</html>
